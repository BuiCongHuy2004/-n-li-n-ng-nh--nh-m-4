# Database
- `users`: Chứa danh sách tài khoản giáo viên và sinh viên
    - `name`: Họ và tên
    - `username`: Tài khoản đăng nhập (nếu là sinh viên thì `username` tương đương Mã số sinh viên)
    - `email`: Email liên hệ
    - `password`: Mật khẩu (sẽ mã hóa khi lưu vào database)
    - `role`: Chức vụ (`student`: Sinh viên, `teacher`: Giáo viên)
    - `profile_id`: ID của profile tương ứng, nếu `role` là `student` thì nó sẽ trỏ đến ID tương ứng trong bảng `student_profiles`, nếu `role` là `teacher` sẽ trỏ đến `teacher_profiles`
- `classes`: Chứa danh sách các lớp học
    - `name`: Tên lớp
- `teacher_profiles`: Lưu thông tin tương ứng với user của giáo viên
- `student_profiles`: Lưu thông tin tương ứng với user của sinh viên
    - `dob`: Ngày sinh
    - `code`: Mã số sinh viên
    - `class_id`: Lớp của sinh viên, trỏ đến ID tương ứng trong bảng `classes`
- `subjects`: Lưu thông tin các môn học
    - `name`: Tên môn
    - `code`: Mã môn
    - `semester`: Kỳ học
- `teacher_subject`: Lưu thông tin các giáo viên sẻ đảm nhận dạy môn học nào
    - `teacher_id`: Trỏ đến ID tương ứng trong bảng `teacher_profiles`
    - `subject_id`: Trỏ đến ID tương ứng trong bảng `subjects`
- `scores`: Lưu thông tin điểm của từng sinh viên với từng môn học
    - `student_id`: Trỏ đến ID tương ứng trong bảng `student_profiles`
    - `subject_id`: Trỏ đến ID tương ứng trong bảng `subjects`
    - `tp1`: Điểm thành phần 1
    - `tp2`: Điểm thành phần 2
    - `qt`: Điểm quá trình
    - `ck`: Điểm cuối kì
    - `tk`: Điểm tổng kết


# Tài khoản mặc định
- Sinh viên:
    - Tài khoản: `mssv`
    - Mật khẩu: `password`

- Giáo viên:
    - Tài khoản: `teacher`
    - Mật khẩu: `password`

# Cách chạy code
-Thầy tải XAMPP và đưa thư mục "btl-daln" vào file htdocs
-Chạy phpMyAdmin trên nền web và import file database