<div class="alert alert-success alert-dismissible text-white" role="alert">
    <span class="text-sm"><?php echo e($message ?? ''); ?></span>
    <button type="button" class="btn-close text-lg py-3 opacity-10" data-bs-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div><?php /**PATH C:\xampp\htdocs\nhom7\resources\views/components/success-alert.blade.php ENDPATH**/ ?>