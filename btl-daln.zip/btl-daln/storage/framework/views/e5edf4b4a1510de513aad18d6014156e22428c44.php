
<?php $__env->startSection('page_title', 'Danh sách điểm của môn: '.$rec->name); ?>
<?php $__env->startSection('slot'); ?>
<div class="card">
    <div class="card-body px-0 pb-2">
        <div class="table-responsive p-0">
            <table class="table align-items-center mb-0">
                <thead>
                    <tr>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Họ và tên sinh viên</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Mã số sinh viên</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Điểm thành phần 1</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Điểm thành phần 2</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Điểm quá trình</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Điểm cuối kì</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Điểm tổng kết</th>
                        <th class="text-secondary opacity-7"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-xs"><?php echo e($row->student->user->name); ?></td>
                        <td class="text-xs"><?php echo e($row->student->code); ?></td>
                        <td class="text-xs"><?php echo e($row->tp1); ?></td>
                        <td class="text-xs"><?php echo e($row->tp2); ?></td>
                        <td class="text-xs"><?php echo e($row->qt); ?></td>
                        <td class="text-xs"><?php echo e($row->ck); ?></td>
                        <td class="text-xs"><?php echo e($row->tk); ?></td>
                        <td class="align-middle">
                            <a class="text-secondary font-weight-bold text-xs"
                                href="<?php echo e(route('scores.edit', ['id' => $row->id])); ?>">Sửa</a> | 
                            <a class="text-secondary font-weight-bold text-xs"
                                href="<?php echo e(route('scores.delete', ['id' => $row->id])); ?>">Xóa</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td class="align-middle text-secondary font-weight-bold text-xs">Không có dữ liệu</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nhom8\resources\views/scores/subject/index.blade.php ENDPATH**/ ?>