
<?php $__env->startSection('page_title', 'Yêu cầu sửa điểm'); ?>
<?php $__env->startSection('slot'); ?>
<form id="form" class="text-start" method="POST" action="<?php echo e(route('scores.request_edit.create', ['id' => $rec->id])); ?>">
    <?php echo e(csrf_field()); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <label class="form-label mt-3">Điểm thành phần 1 *</label>
                <div class="input-group input-group-outline">
                    <input disabled type="number" step="0.01" name="tp1" class="form-control" required value="<?php echo e($rec->tp1 ?? old('tp1') ?? ''); ?>">
                </div>
            </div>
            <div class="col-md-4">
                <label class="form-label mt-3">Điểm thành phần 2</label>
                <div class="input-group input-group-outline">
                    <input disabled type="number" step="0.01" name="tp2" class="form-control" value="<?php echo e($rec->tp2 ?? old('tp2') ?? ''); ?>">
                </div>
            </div>
            <div class="col-md-4">
                <label class="form-label mt-3">Điểm quá trình</label>
                <div class="input-group input-group-outline">
                    <input disabled type="number" step="0.01" name="qt" class="form-control" value="<?php echo e($rec->qt ?? old('qt') ?? ''); ?>">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <label class="form-label mt-3">Điểm cuối kì</label>
                <div class="input-group input-group-outline">
                    <input disabled type="number" step="0.01" name="ck" class="form-control" value="<?php echo e($rec->ck ?? old('ck') ?? ''); ?>">
                </div>
            </div>
            <div class="col-md-6">
                <label class="form-label mt-3">Điểm tổng kết</label>
                <div class="input-group input-group-outline">
                    <input disabled type="number" step="0.01" name="tk" class="form-control" value="<?php echo e($rec->tk ?? old('tk') ?? ''); ?>">
                </div>
            </div>
        </div>
        <label class="form-label mt-3">Sinh viên: <?php echo e($rec->student->user->name); ?> - <?php echo e($rec->student->code); ?></label><br>
        <label class="form-label mt-3">Môn học: <?php echo e($rec->subject->name); ?> - <?php echo e($rec->subject->code); ?></label>
        <div class="col-md-12">
            <label class="form-label mt-3">Tin nhắn</label>
            <div class="input-group input-group-outline">
                <input type="text" name="message" class="form-control" value="<?php echo e($rec->message ?? old('message') ?? ''); ?>">
            </div>
        </div>
    </div>

    <input type="submit" class="btn bg-gradient-primary my-4 mb-2" value="Yêu cầu">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\Github\da\resources\views/scores/request_edit_form.blade.php ENDPATH**/ ?>