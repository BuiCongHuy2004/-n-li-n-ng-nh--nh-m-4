
<?php $__env->startSection('page_title', isset($rec) ? 'Cập nhật môn học: '.$rec->name : 'Thêm môn học'); ?>
<?php $__env->startSection('slot'); ?>
<form id="form" class="text-start" method="POST"
    action="<?php echo e(isset($rec) ? route('subjects.update', ['id' => $rec->id]) : route('subjects.create')); ?>">
    <?php echo e(csrf_field()); ?>

    <label class="form-label mt-3">Tên môn *</label>
    <div class="input-group input-group-outline">
        <input type="text" name="name" class="form-control" required value="<?php echo e($rec->name ?? old('name') ?? ''); ?>">
    </div>

    <label class="form-label mt-3">Mã môn *</label>
    <div class="input-group input-group-outline">
        <input type="text" name="code" class="form-control" required value="<?php echo e($rec->code ?? old('code') ?? ''); ?>">
    </div>

    <label class="form-label mt-3">Kì học *</label>
    <div class="input-group input-group-outline">
        <input type="number" name="semester" class="form-control" required value="<?php echo e($rec->semester ?? old('semester') ?? ''); ?>">
    </div>

    <label class="form-label mt-3">Giáo viên</label>
    <div class="overflow-auto" style="max-height: 50vh;">
        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $check = false;
        if(isset($teacher_subject_list))
            foreach($teacher_subject_list as $index => $roww) {
                if($roww->teacherProfile->id == $row->profile->id) {
                    $check = true;
                    unset($teacher_subject_list[$index]);
                    break;
                }
            }
        ?>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="teacher_id[]"
                value="<?php echo e($row->profile->id); ?>" <?php echo e($check ? 'checked' : ''); ?>>
            <label class="custom-control-label" for="customRadio1"><?php echo e($row->name); ?></label>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <input type="submit" class="btn bg-gradient-primary my-4 mb-2" value="<?php echo e(isset($rec) ? 'Cập nhật' : 'Thêm'); ?>">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\da\resources\views/subjects/form.blade.php ENDPATH**/ ?>