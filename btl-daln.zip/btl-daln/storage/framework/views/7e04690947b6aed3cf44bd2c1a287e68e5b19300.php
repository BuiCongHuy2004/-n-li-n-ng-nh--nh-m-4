
<?php $__env->startSection('page_title', 'Điểm của sinh viên: '.$rec->user->name); ?>
<?php $__env->startSection('slot'); ?>
<div class="card">
    <div class="card-body px-0 pb-2">
        <div class="table-responsive p-0">
            <table class="table align-items-center mb-0">
                <thead>
                    <tr>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Tên môn</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Mã môn</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Điểm thành phần 1</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Điểm thành phần 2</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Điểm quá trình</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Điểm cuối kì</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Tổng kết</th>
                        <th class="text-secondary opacity-7"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-xs"><?php echo e($row->subject->name); ?></td>
                        <td class="text-xs"><?php echo e($row->subject->code); ?></td>
                        <td class="text-xs"><?php echo e($row->tp1); ?></td>
                        <td class="text-xs"><?php echo e($row->tp2); ?></td>
                        <td class="text-xs"><?php echo e($row->qt); ?></td>
                        <td class="text-xs"><?php echo e($row->ck); ?></td>
                        <td class="text-xs"><?php echo e($row->tk); ?></td>
                        <td class="align-middle">
                            <?php if(in_array(auth()->user()->role, ['student'])): ?>
                            <a class="text-secondary font-weight-bold text-xs"
                                href="<?php echo e(route('scores.request_edit.add', ['id' => $row->id])); ?>">Yêu cầu sửa điểm</a>
                            <?php endif; ?>
                            <?php if(in_array(auth()->user()->role, ['teacher'])): ?>
                            <a class="text-secondary font-weight-bold text-xs"
                                href="<?php echo e(route('scores.edit', ['id' => $row->id])); ?>">Sửa</a> | 
                            <a class="text-secondary font-weight-bold text-xs"
                                href="<?php echo e(route('scores.delete', ['id' => $row->id])); ?>">Xóa</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td class="align-middle text-secondary font-weight-bold text-xs">Không có dữ liệu</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\Github\da\resources\views/scores/student/index.blade.php ENDPATH**/ ?>