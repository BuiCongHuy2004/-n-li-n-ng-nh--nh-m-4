
<?php $__env->startSection('page_title', 'Danh sách sinh viên trong lớp: '.$rec->name); ?>
<?php $__env->startSection('slot'); ?>
<div class="card">
    <div class="card-body px-0 pb-2">
        <div class="table-responsive p-0">
            <table class="table align-items-center mb-0">
                <thead>
                    <tr>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Họ và tên</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Mã số sinh viên</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Ngày sinh</th>
                        <th class="text-secondary opacity-7"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $rec->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-xs"><?php echo e($row->user->name); ?></td>
                        <td class="text-xs"><?php echo e($row->code); ?></td>
                        <td class="text-xs"><?php echo e(date('d/m/Y', strtotime($row->dob))); ?></td>
                        <td class="align-middle">
                            <?php if(in_array(auth()->user()->role, ['teacher'])): ?>
                            <a class="text-secondary font-weight-bold text-xs"
                                href="<?php echo e(route('students.edit', ['id' => $row->user->id])); ?>">Sửa</a> | 
                            <a class="text-secondary font-weight-bold text-xs"
                                href="<?php echo e(route('students.delete', ['id' => $row->user->id])); ?>">Xóa</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td class="align-middle text-secondary font-weight-bold text-xs">Không có dữ liệu</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\Github\da\resources\views/classes/student_list.blade.php ENDPATH**/ ?>