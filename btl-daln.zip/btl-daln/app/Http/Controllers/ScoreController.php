<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Score as MainModel;
use App\Models\Subject;
use App\Models\User;
use App\Models\RequestEditScore;
use App\Models\Classroom;
use App\Models\StudentProfile;
use Illuminate\Support\Facades\DB;


class ScoreController extends Controller
{
    public function viewSubjects()
    {
        $data['rows'] = Subject::all();
        return view('scores.subject.list', $data);
    }

    public function bySubject($id)
    {
        $data['rows'] = MainModel::where('subject_id', $id)->get();
        $data['rec'] = Subject::findOrFail($id);
        foreach ($data['rows'] as $row) {
        $row->status = ($row->tk < 4.0) ? 'Trượt' : 'Đạt';
        }
        return view('scores.subject.index', $data);
    }

    public function viewStudents()
    {
        $data['rows'] = User::where('role', 'student')->get();
        return view('scores.student.list', $data);
    }

    public function byStudent($id)
    {
        $data['rows'] = MainModel::where('student_id', $id)->get();
        $data['rec'] = StudentProfile::findOrFail($id);
        return view('scores.student.index', $data);
    }

   public function viewSemesters()
{
    if(auth()->user()->role == 'student') {
        $user = auth()->user();
        $semesters = [];
        $scores = MainModel::where('student_id', $user->profile->id)->get();
        foreach($scores as $score) {
            if(!in_array($score->subject->semester, $semesters))
                $semesters[] = $score->subject->semester;
        }
        sort($semesters);
        foreach($semesters as $index => $semester) {
            $semesters[$index] = ['semester' => $semester];
        }
        $data['rows'] = $semesters;

        $total10 = 0;
        $total4  = 0;
        $count   = 0;
        foreach ($scores as $score) {
            if (!is_null($score->tk)) {
                $tk = floatval($score->tk);
                $total10 += $tk;
                if ($tk >= 8.5) $g4 = 4.0;
                elseif ($tk >= 7.0) $g4 = 3.0;
                elseif ($tk >= 5.5) $g4 = 2.0;
                elseif ($tk >= 4.0) $g4 = 1.0;
                else $g4 = 0.0;

                $total4 += $g4;
                $count++;
            }
        }

        $data['gpa_year'] = [
            'gpa10' => $count ? round($total10 / $count, 2) : 0,
            'gpa4'  => $count ? round($total4 / $count, 2) : 0,
            'name'  => $user->name ?? 'Không rõ',
            'code'  => $user->profile->code ?? ''
        ];
    } else {
        $data['rows'] = Subject::select('semester')->distinct()->orderBy('semester', 'DESC')->get();
        $data['gpa_year'] = ['gpa10' => 0.00, 'gpa4' => 0.00];
    }

    return view('scores.semester.list', $data);
}



     public function bySemester(Request $request, $semester) {
    $data['rec'] = $semester;
    $data['rows'] = MainModel::with(['student.user', 'subject'])->get();
    $data['rows_filtered'] = [];

    foreach ($data['rows'] as $row) {
        if ($row->subject->semester == $semester) {
            if (
                !(auth()->user()->role == 'student')
                || (auth()->user()->role == 'student' && auth()->user()->profile->id == $row->student->id)
            ) {
                array_push($data['rows_filtered'], $row);
            }
        }
    }

    $data['rows'] = $data['rows_filtered'];

    $grouped = collect($data['rows'])->groupBy('student_id');
    $gpaByStudent = [];

    foreach ($grouped as $studentId => $grades) {
        $total10 = 0;
        $total4 = 0;
        $count = count($grades);

        foreach ($grades as $g) {
            $tk = floatval($g->tk ?? 0);
            $total10 += $tk;
            $total4 += $this->convertTo4Scale($tk);
        }

        $gpa10 = $count ? round($total10 / $count, 2) : 0;
        $gpa4 = $count ? round($total4 / $count, 2) : 0;

        $gpaByStudent[$studentId] = [
            'gpa10' => $gpa10,
            'gpa4' => $gpa4,
            'name' => $grades->first()->student->user->name ?? 'Không rõ',
            'code' => $grades->first()->student->code ?? '',
        ];
    }

    if (auth()->check() && auth()->user()->role == 'student') {
        $studentProfileId = auth()->user()->profile->id;
        $data['gpa'] = $gpaByStudent[$studentProfileId] ?? ['gpa10' => 0, 'gpa4' => 0];
    } else {
        $data['gpaByStudent'] = $gpaByStudent;
        $data['gpa'] = ['gpa10' => 0, 'gpa4' => 0];
    }

    return view('scores.semester.index', $data);
}

private function convertTo4Scale($tk)
{
    if ($tk >= 8.5) return 4.0;
    if ($tk >= 7.0) return 3.0;
    if ($tk >= 5.5) return 2.0;
    if ($tk >= 4.0) return 1.0;
    return 0.0;
}

    public function viewClassrooms()
    {
        $data['rows'] = Classroom::all();
        return view('scores.classroom.list', $data);
    }

    public function byClassroom(Request $request, $id)
    {
        $data['rec'] = Classroom::findOrFail($id);
        $data['rows'] = MainModel::all();
        $data['rows_filtered'] = [];
        foreach ($data['rows'] as $row) {
            if ($row->student->class->id == $id) {
                array_push($data['rows_filtered'], $row);
            }
        }
        $data['rows'] = $data['rows_filtered'];
        return view('scores.classroom.index', $data);
    }

    public function add()
    {
        $data['subjects'] = Subject::all();
        $data['students'] = User::where('role', 'student')->get();
        return view('scores.form')->with($data);
    }

    public function create(Request $request)
    {
        try {
            $params = $request->all();
          DB::transaction(function () use ($params) {
    $tp1 = floatval($params['tp1'] ?? 0);
    $tp2 = floatval($params['tp2'] ?? 0);
    $qt  = floatval($params['qt'] ?? 0);
    $ck  = floatval($params['ck'] ?? 0);
    $params['tk'] = (($tp1 + $tp2) / 2) * 0.3 + $qt * 0.2 + $ck * 0.5;

    MainModel::create($params);
});
            return redirect()->route('scores.students')->withSuccess("Đã thêm");
        } catch (\Exception $e) {
            return redirect()->back()->withError($e->getMessage())->withInput();
        }
    }

    public function edit($id)
    {
        $data['subjects'] = Subject::all();
        $data['students'] = User::where('role', 'student')->get();
        $data['rec'] = MainModel::findOrFail($id);
        return view('scores.form')->with($data);
    }

    public function update(Request $request, $id)
    {
        try {
            $rec = MainModel::findOrFail($id);
            $params = $request->all();
            DB::transaction(function () use ($params, $rec) {

    $tp1 = floatval($params['tp1'] ?? 0);
    $tp2 = floatval($params['tp2'] ?? 0);
    $qt  = floatval($params['qt'] ?? 0);
    $ck  = floatval($params['ck'] ?? 0);
    $params['tk'] = (($tp1 + $tp2) / 2) * 0.3 + $qt * 0.2 + $ck * 0.5;

    $rec->update($params);
});
            return redirect()->route('scores.students')->withSuccess("Đã cập nhật");
        } catch (\Exception $e) {
            return redirect()->back()->withError($e->getMessage())->withInput();
        }
    }

    public function delete($id)
    {
        try {
            $rec = MainModel::findOrFail($id);
            $rec->delete();
            return redirect()->back()->withSuccess("Đã xóa");
        } catch (\Exception $e) {
            return redirect()->back()->withError($e->getMessage());
        }
    }

    public function requestEdit() {
        $data['rows'] = RequestEditScore::all();
        return view('scores.request_edit', $data);
    }

    public function requestEditAdd($id) {
        $data['rec'] = MainModel::findOrFail($id);
        return view('scores.request_edit_form', $data);
    }

    public function calculateGPA($studentId, $semester) {
    $grades = Grade::where('student_id', $studentId)
        ->where('semester', $semester)
        ->get();

    if ($grades->isEmpty()) {
        return ['gpa10' => 0, 'gpa4' => 0];
    }

    $total10 = 0;
    $total4 = 0;

    foreach ($grades as $grade) {
        $score = $grade->diem_tong_ket;


        $total10 += $score;

        if ($score >= 8.5) $total4 += 4.0;
        elseif ($score >= 7.0) $total4 += 3.0;
        elseif ($score >= 5.5) $total4 += 2.0;
        elseif ($score >= 4.0) $total4 += 1.0;
        else $total4 += 0.0;
    }

    $count = $grades->count();
    $gpa10 = round($total10 / $count, 2);
    $gpa4 = round($total4 / $count, 2);

    GPA::updateOrCreate(
        ['student_id' => $studentId, 'semester' => $semester],
        ['gpa10' => $gpa10, 'gpa4' => $gpa4]
    );

    return ['gpa10' => $gpa10, 'gpa4' => $gpa4];
  }
  
  public function calculateYearGPA($studentId, $year) {
    $semesters = GPA::where('student_id', $studentId)
        ->whereBetween('semester', [($year - 1)*2 + 1, $year*2])
        ->get();

    if ($semesters->isEmpty()) return ['gpa10' => 0, 'gpa4' => 0];

    $gpa10 = round($semesters->avg('gpa10'), 2);
    $gpa4 = round($semesters->avg('gpa4'), 2);

    return ['gpa10' => $gpa10, 'gpa4' => $gpa4];
  }

  public function showSemesterGrades($studentId, $semester) {
    $grades = Grade::where('student_id', $studentId)
        ->where('semester', $semester)
        ->get();

    $gpa = $this->calculateGPA($studentId, $semester);

    return view('grades.semester', compact('grades', 'gpa'));
  }

}
