@extends('layout.base')
@section('page_title', 'Chọn kì học để xem điểm')
@section('slot')
<div class="card">
    <div class="card-body px-0 pb-2">
        <div class="table-responsive p-0">
            <table class="table align-items-center mb-0">
                <thead>
                    <tr>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Kì học</th>
                        <th class="text-secondary opacity-7"></th>
                    </tr>
                    <tr>
                         <td colspan="8" class="text-center font-bold text-danger">
                             {{ $gpa_year['name'] ?? '' }} 
                             GPA hệ 10: {{ $gpa_year['gpa10'] ?? 0 }} | 
                             GPA hệ 4: {{ $gpa_year['gpa4'] ?? 0 }}
                         </td>
                    </tr>
                </thead>
                <tbody>
                    @forelse($rows as $row)
                    <tr>
                        <td class="text-xs">{{$row['semester']}}</td>
                        <td class="align-middle">
                            <a class="text-secondary font-weight-bold text-xs"
                                href="{{route('scores.semester', ['id' => $row['semester']])}}">Xem điểm</a>
                        </td>
                    </tr>
                    @empty
                    <tr><td class="align-middle text-secondary font-weight-bold text-xs">Không có dữ liệu</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@stop